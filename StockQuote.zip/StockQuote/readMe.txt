To Run this application

Requirements:

Place a file named "text.txt" in the path: "f://project/text.txt"

Internet connection is needed.

After successful completion, it will display the contents red from the file named
text.txt , 

Results:

Descending order based total price of the individual line
---------------------------------------------------------------------------

Procedure followed to obtain the results


Open the connection url http://finance.yahoo.com/d/quotes.csv?s=GOOG+AAPL&f=snl1

This file will have "AAPL","Apple Inc","343.56" like this..

From this extract the price and use it in program for calculation and display
