package com.net.stock;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

/**
 * This class is used to run the test case of array assertions
 * @author dell
 *
 */
public class TestRunner1 {
	public static void main(String arg[]) {
		Result result = JUnitCore.runClasses(TestAssertions.class);
		for(Failure failure:result.getFailures()) {
			System.out.println(failure.toString());
		}
		System.out.println(result.wasSuccessful());
	}
}
