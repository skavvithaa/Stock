package com.net.stock;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 * This class is used to for Junit test
 * @author dell
 *
 */
public class TestJunit {
	String message = "Testing Stock Details Calculation";	
	MessageUtil  messageUtil = new MessageUtil(message);

	   @Test
	   public void testPrintMessage() {	  
	      assertEquals(message,messageUtil.printMessage());
	   }
}
