package com.net.stock;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * This class is used to test the assert array for Junit purpose
 * @author dell
 *
 */
public class TestAssertions {

	@Test
	public void testAssertions() {
		String expectedArray[] = {"AAP-30","GOOG-55"};
		String resultArray[] = {"AAP-30","GOOG-55"};
		assertArrayEquals(expectedArray,resultArray);
	}
}
