package com.net.stock;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

/**
 * This class is used to read the portfolio from the text file named as "test.txt"
 * based on the information given get the symbol(AAP), symbol's share count. Get the 
 * stock price of the symbol from the site fianance.yahoo.com as a csv file named quotes.csv.
 * 
 * Calulate the total stock price of each line with respect to symbol and display them in
 * descending order
 * 
 * @author dell
 *
 */

public class Stock {
	static HashMap<String,String> stockPriceHashMap= new HashMap<String,String>();
	static HashMap<String,String> lineHashMap= new HashMap<String,String>();
	static TreeMap<String, Double> totalPriceHM=new TreeMap<String, Double>();
	 
	 
	public static void main(String arg[]) throws IOException {
	System.out.println("Demo");

	ArrayList<String> arr = new ArrayList<String>();
	doLoadStockPriceFromWebSite();
	readFileContentAndStore();
	storeStockValueAndTotal();
	System.out.println("Final Output");
	doDisplayInConsole();
	
	}

	

	/**
	 * Method Name : doDisplayInConsole
	 * Input Parameters: void 
	 * Return Type: void
	 * Description: This method is called from a main to display the portfolio in console
	 * descending order based on the total stock price value of every line from the 
	 * given file
	 */
	private static void doDisplayInConsole() {
		// TODO Auto-generated method stub
		
		//Total price hash map has line number as key and total stock price as value
		
		Set<Entry<String, Double>> set = totalPriceHM.entrySet();
		
		// List is used to sort the value of stock price
		
		List<Entry<String,Double>> list = new ArrayList<Entry<String,Double>>(set);
		Collections.sort(list,new Comparator<Map.Entry<String,Double>>(){
			public int compare(Map.Entry<String,Double>o1,Map.Entry<String,Double>o2) {
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});
			
		
		String keyOfPriceMap;	
		String valueFromFile;
		for(Map.Entry<String,Double>entry:list) {			
			keyOfPriceMap = entry.getKey();
			valueFromFile=lineHashMap.get(keyOfPriceMap);
			System.out.println(valueFromFile);
		}
	}

	/**
	 * Method Name: doLoadStockPriceFromWebSite
	 * Input Parameters:void
	 * Return Type: void
	 * Description : This method is used to read the contents from csv which is obtained
	 * from the link given and store the value in hash map
	 * @throws IOException
	 */
	private static void doLoadStockPriceFromWebSite() throws IOException {
		// TODO Auto-generated method stub
		
		//URL is used to connect to the finance.yahoo.com 
		URL url = new URL("http://download.finance.yahoo.com/d/quotes.csv?s=GOOG+AAPL&f=snl1");
		
		//Opens up the connection
		URLConnection con = url.openConnection();
		
		//InputStream is used to read the file named quotes.csv
		
		InputStream is =con.getInputStream();
    
		
		BufferedReader br = new BufferedReader(new InputStreamReader(is));

		//line variable to read from file
		String line = null;
    
		// stockData will have the data in array after split the line with comma separated
		String stockData[];
		String symbol;
		String price;
		// read each line and write to System.out
		while ((line = br.readLine()) != null) {			
			stockData = line.split(",",-1);			
			symbol = stockData[0];
			price = stockData[2];
			//Remove the "" from the variable symbol
			symbol = symbol.replaceAll("^\"|\"$", "");
			//Store in the hash map, symbol as key and price as a value
			stockPriceHashMap.put(symbol, price);
		}
	
	}

	/**
	 * Method Name:storeStockValueAndTotal
	 * Input Parameter:void
	 * Return Type:void
	 * Description: This method is used to calculate the stock price of each line
	 * 
	 */
	private static void storeStockValueAndTotal() {
		// TODO Auto-generated method stub
	
		String data;
		String splitData[];
		String share[];
		double shareValue = 0;
		double totalValue=0;
		double stock=0;
		// Iterate a map lineHashMap 
		for(Map.Entry<String,String> m:lineHashMap.entrySet()){ 
			totalValue=0;
			data=m.getValue();
			//Data will be comma separated AAPL-20, AAPL-30, GOOG-50
			splitData=data.split(",",-1);		 
			int commaIdx;
			for(commaIdx=0;commaIdx<splitData.length;commaIdx++) {	
				// hypen splited AAPL-20
				share=splitData[commaIdx].split("-");
				for(int hyphenIdx=0;hyphenIdx<share.length;hyphenIdx++) {
					// oth index will have symbol, get the price of symbol from map
					stock = getStockPrice(share[0].trim());
					//1st will have shares count
					shareValue = Integer.parseInt(share[1]);
				}
				// Calculate total = stock * shareValue
				totalValue = totalValue +(stock*shareValue);
			}
			String lineKey = m.getKey();
			// totalPriceHM key as line number and total as value
			totalPriceHM.put(lineKey, totalValue);
		}
	}

	/**
	 * Method Name: getStockPrice
	 * Input Parameter : Symbol as String
	 * Return type: Price value as double
	 * Description : This method is used to get the price from the map based on symbol
	 */
	private static double getStockPrice(String symbol) {
		// TODO Auto-generated method stub
			double stock = Double.parseDouble(stockPriceHashMap.get(symbol));
			return stock;
	
	}

	/**
	 * Method Name: readFileContentAndStore
	 * Input Parameter : void
	 * Return Type : void
	 * Description : This method will read the file content
	 */
	private static void readFileContentAndStore() {
		// TODO Auto-generated method stub
	
		try {
		
			//Reading a path from 
			FileInputStream fileStream=new FileInputStream("f://project/text.txt");
		
			
			DataInputStream dataIn = new DataInputStream(fileStream);		
			BufferedReader br = new BufferedReader(new InputStreamReader(dataIn));
			
			String strLine;
			int lineIdx = 1;
			//  The collection hash map is used to store the content from file.
			//	The Key for the hash map is line number and values is the content from the file
		
			ArrayList<String> arrayList = new ArrayList();
			while((strLine = br.readLine())!= null) {
				arrayList.add(strLine);
				lineHashMap.put(""+lineIdx, strLine);
				lineIdx++;				
			}		
		
			System.out.println("Reading from File");
			Iterator itr = arrayList.iterator();
			while(itr.hasNext()) {
				System.out.println(itr.next());
			}
		
		}catch(Exception e) {
		
		}
	}
}
