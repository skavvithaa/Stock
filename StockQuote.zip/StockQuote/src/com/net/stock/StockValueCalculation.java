package com.net.stock;
/**
 * This class is used to check the caluclation of stock and share
 * @author dell
 *
 */


public class StockValueCalculation {

	/**
	 * This method is used to calulate share and stock price for checking Junit purpose
	 * @param objStock
	 * @return
	 */
	public double calculateTotalPrice(StockDetails objStock) {
		double totalPrice = objStock.getShare() * objStock.getStockPrice();
		return totalPrice;
	}
}
