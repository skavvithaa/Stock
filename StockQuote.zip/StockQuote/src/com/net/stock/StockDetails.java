package com.net.stock;

/**
 * This class is used to assign and get the stock details for Junit purpose
 * @author dell
 *
 */
public class StockDetails {
	private String symbol;
	private double stockPrice;
	private double share;

	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	public double getShare() {
		return share;
	}
	public void setShare(double share) {
		this.share = share;
	}
}
