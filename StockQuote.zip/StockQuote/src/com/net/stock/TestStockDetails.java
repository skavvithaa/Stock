package com.net.stock;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * This class is used to set the information stock to check for unit test purpose
 * @author dell
 *
 */
public class TestStockDetails {
	
	StockValueCalculation objStockValueCalculation = new StockValueCalculation();
	StockDetails objStockDetails = new StockDetails();
	
	@Test
	public void testCalculation() {
		objStockDetails.setSymbol("AAP");
		objStockDetails.setStockPrice(56.66);
		double total = objStockValueCalculation.calculateTotalPrice(objStockDetails);
	}
}
